/*
    var - pode ser declaradas diversas vezes
    let - variável única, não pode ser re-declarada, é ótimo quando tem blocos de código
    const -  nunca aceita mudanças
*/

